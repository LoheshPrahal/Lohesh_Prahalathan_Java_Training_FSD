package com.maverickbank.repository;

import com.maverickbank.model.AccountClosureRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountClosureRequestRepository extends JpaRepository<AccountClosureRequest, Long> {
}
